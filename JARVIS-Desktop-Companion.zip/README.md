# JARVIS Desktop Companion · Mark V

Optional companion for the JARVIS website. It opens a small set of apps and standard folders on the computer where you run it. It does not provide arbitrary computer control.

## Start and pair

1. Install Node.js **22 or newer** from https://nodejs.org/ if it is not already installed. No npm packages are needed.
2. Extract all files from this ZIP into one folder.
3. Windows: double-click `START-WINDOWS.cmd`. macOS/Linux: in an interactive terminal, run `node companion.cjs` from this folder.
4. Keep the terminal open. Copy the pairing code it shows (do not paste it into chat).
5. On the **same computer**, open https://jarvis-voice-assistant-bay.vercel.app/ or https://modifyingtiwari-design.github.io/jarvis-voice-assistant/ in Chrome or Edge. Choose **Device tools**, select permissions, paste the code and select **Pair this computer**. Allow local-network access if asked. Do not disable browser protections to connect.
6. In the companion terminal, type `yes` to approve pairing. Each later app/folder request also needs a separate `yes` there. Requests expire after 45 seconds.
7. Type or say “Open calculator”, “Open notepad”, “Open documents”, “Open downloads” or “Open home folder”. Review the action in JARVIS, then approve it in the terminal.

## What it can do

- Windows: Calculator, Notepad, Explorer opening Home/Documents/Downloads.
- macOS: Calculator, TextEdit, Finder opening Home/Documents/Downloads.
- Linux: GNOME Calculator, gedit, xdg-open for Home/Documents/Downloads, if those programs are installed at their standard paths.
- Opening a redirected or customized Documents/Downloads folder is not supported. The browser file picker can still choose files there.

Phone browsers use JARVIS's selected-text-file editor, download and native share sheet. This companion does not remotely control your computer from a phone, automate iOS/Android apps, send messages, type in other apps, scan local files, delete files, install software or execute shell commands.

## Permissions and security

The server binds only to `127.0.0.1:4317`. It accepts the two published JARVIS origins only, validates the Host header, requires JSON and a random in-memory token, and uses argument arrays with `shell:false`. It has no filesystem read/write or arbitrary-command endpoint. Browser privacy features may block loopback access; use a supported browser and normal permission prompts, never disable security protections.

The pairing code expires in 10 minutes. A paired session lasts 30 minutes. Pairing again revokes the previous session. Choose only the apps/folders permissions you want. Disconnect in the website to revoke its session; **close the terminal or press Ctrl+C to stop all access immediately**. Refreshing the website forgets its session token; restart the companion if you need a fresh pairing code. No token is written to disk. The companion makes no outbound network requests.

App launch status means the operating system accepted the launch request, not that JARVIS has read the app or completed a task inside it. Website AI outputs cannot call the companion; only user commands and explicit UI controls can request these fixed actions.

## Files in the website

The separate browser file workspace reads only a file you select. Supported files are UTF-8 text up to 1 MB; PDF and Word are not parsed. Save uses a file picker/download and does not automatically overwrite the source. AI summaries require a separate checkbox and send the editor text (up to 50,000 characters) to Sarvam. File contents are never read by this companion.

## Typed app commands

Voice is optional. After pairing, type a command in **Device tools → Type a command** or in the main message box, then select **Run command / Send**. For example: “Please open calculator for me”, “Can you open the downloads folder?” or “Launch notepad”. Review the action and type **yes** in the companion terminal. No microphone or Sarvam API key is needed for these local app commands. If pairing is missing or its permission does not cover the command, JARVIS keeps the task pending while you pair. Buttons for Calculator, Text editor, Documents and Downloads use the same command flow.
