# JARVIS Desktop Companion 6.0

## Upgrade and pair

1. Close the old companion terminal. Extract every file in this ZIP into a new folder.
2. Install Node.js 22+ from https://nodejs.org/ if needed. No npm packages are required.
3. On Windows, double-click START-WINDOWS.cmd. Keep the terminal open. Do not run as administrator.
4. Open https://modifyingtiwari-design.github.io/jarvis-voice-assistant/ or https://jarvis-voice-assistant-bay.vercel.app/ in Chrome or Edge on the same computer.
5. In Device tools, paste the pairing code, choose permissions, and select Pair this computer. Allow local-network access if the browser asks; do not disable browser protections.
6. For routine launches without repeated prompts, check Trusted session for 30 minutes. For app tasks, also check Windows app reading/control permission.
7. Review the permissions in the companion terminal and type yes once. App access is off until you select it.

Windows app access compiles the included fixed DesktopBridge.cs source into DesktopBridge.exe using the Windows .NET Framework 4.x compiler. The extracted folder must be writable. No downloaded executable or model-generated code is run. If Windows or your administrator blocks compilation, the website reports it; do not bypass those protections.

## Routine launch commands

Type or say Open google chrome, Open calculator, Open notepad, Open home folder, Open documents, or Open downloads. The main text box, voice and Device tools command box share the same launcher. A Sarvam key is not needed for these launches.

Trusted mode skips repeated browser/terminal prompts for these supported launches. Otherwise, each launch asks. A launch result means the OS accepted the request, not that a task inside the app finished. Standard installation paths are required; redirected/custom folders are not supported.

Open gmail.com or Open google requests a website in the current browser. Open google chrome and search weather requests Chrome with an HTTPS search URL. These launch commands do not read webpages.

## Windows App agent

1. Connect your own Sarvam subscription key in JARVIS Settings.
2. Open the Windows app you want to operate. Keep its window available and avoid editing it while JARVIS acts.
3. Choose App agent > Refresh open apps, then choose that window.
4. Enter a task, check permission to send the selected app's text and controls to Sarvam for this task, and select Start app task.
5. Follow its step log. If a step needs approval, review the exact action in the terminal and type yes.

You can also select an app and check task permission, close the panel, then type or say "Agent: [your task]" in the main box. Ordinary chat is not automatically computer control. Voice is optional. Example: "Enter 125 multiplied by 8 in Calculator and tell me the result."

Each run is limited to one selected app, 12 actions and five minutes. Only one app-control run executes at a time; chat, notes and timers can run alongside it. Refresh the app list before the next run. An unused window list expires after two minutes.

The agent uses Microsoft UI Automation: readable control text, writable ValuePattern fields, buttons, lists, expansion, toggles and scrolling. It observes again after each action. Snapshot tokens and control identities restrict actions to the observed window. App text is treated as untrusted data by the AI planner. The AI can still make mistakes; supervise tasks and review results.

Trusted mode skips routine navigation, field editing and recognized simple buttons. Other buttons, toggles and labels indicating sending, deleting, saving, payments or settings ask in the terminal. This conservative label check cannot guarantee recognition of every sensitive action. Denying a step stops the run.

## Limits

- Accessibility support varies. Canvas interfaces, custom widgets, some modern editors and web controls may not expose the required patterns. Unsupported operations are reported; there is no arbitrary keystroke fallback.
- Password-marked controls and controls labeled as credentials are excluded. Do not select windows displaying secrets or unrelated private information.
- Terminals, several security/system programs, password managers and Windows Settings are excluded. Elevated/UAC/security desktop automation is unsupported. Do not run as administrator.
- No arbitrary shell, code execution, full-disk search or filesystem endpoint is provided.
- No remote phone control, iOS/Android app control, screenshot interpretation or background screen recording is included.
- App observations are bounded and can be truncated; success claims are based on the available accessibility text.
- macOS/Linux retain fixed app/folder launchers using node companion.cjs. Windows app-agent permissions are unavailable there. Linux requires standard gnome-calculator, gedit and xdg-open installations.

## Stop and privacy

Stop task, the task card's Cancel, or "Stop agent" prevents further steps. An action already performed cannot be automatically undone. A stopped/timed-out operation may have completed: inspect the app before retrying. Disconnect revokes the session. Close the companion terminal or press Ctrl+C to stop all access.

Pairing codes expire in ten minutes and sessions in thirty minutes. Tokens stay in memory. The server binds only to 127.0.0.1:4317, accepts the two exact published JARVIS origins, validates Host, and makes no outbound requests. The website sends selected-app text to Sarvam only for a task started with app permission checked. App summaries may enter later chat context. API keys stay in browser memory and go only to Sarvam.

The separate selected-file workspace continues without the companion. File summaries have their own checkbox. Browser/Sarvam voice processing follows the Settings choices.

## Release status

JavaScript syntax checks passed and the helper compiled with Windows .NET Framework. Native app operations were not exercised in this release session. App compatibility and AI task completion are not guaranteed.
