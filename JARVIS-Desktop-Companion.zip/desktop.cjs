'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {spawn}=require('node:child_process');
module.exports=function desktopBridge(confirm){
  let catalog=new Map(),run=null,busy=false,child=null,ready=false;
  const exe=path.join(__dirname,'DesktopBridge.exe');
  function processCall(command,args,input,timeout=12000,res){return new Promise((resolve,reject)=>{
    const p=spawn(command,args,{shell:false,windowsHide:true,stdio:['pipe','pipe','pipe']});child=p;
    let out='',err='',settled=false;
    const stop=()=>finish(Error('Desktop operation cancelled or timed out. Check the app before retrying.'));
    const timer=setTimeout(stop,timeout);const closed=()=>{if(!res.writableEnded)stop();};res?.once('close',closed);
    function finish(error,value){if(settled)return;settled=true;clearTimeout(timer);res?.removeListener('close',closed);if(child===p)child=null;if(error){p.kill();reject(error);}else resolve(value);}
    p.on('error',()=>finish(Error('Could not start Windows accessibility helper.')));
    p.stdout.setEncoding('utf8');p.stderr.setEncoding('utf8');
    p.stdout.on('data',b=>{out+=b;if(out.length>180000)finish(Error('App response exceeded the size limit.'));});
    p.stderr.on('data',b=>{err=(err+b).slice(0,1000);});
    p.on('close',code=>{if(code!==0 && !out.startsWith('{'))finish(Error('Windows helper failed. '+err));else finish(null,out);});
    p.stdin.on('error',()=>{});p.stdin.end(input);
  });}
  async function prepare(){
    if(process.platform!=='win32')throw Error('App inspection and control currently require Windows.');
    if(ready)return;
    const base=path.join(process.env.SystemRoot||'C:\\Windows','Microsoft.NET','Framework64','v4.0.30319');
    const fallback=base.replace('Framework64','Framework'),root=fs.existsSync(path.join(base,'csc.exe'))?base:fallback;
    if(!fs.existsSync(path.join(root,'csc.exe')))throw Error('Windows .NET Framework compiler is unavailable. Enable .NET Framework 4.x in Windows first.');
    const refs=['WPF/UIAutomationClient.dll','WPF/UIAutomationTypes.dll','WPF/WindowsBase.dll','System.Web.Extensions.dll'];
    await processCall(path.join(root,'csc.exe'),['/nologo','/target:exe','/out:'+exe,...refs.map(p=>'/reference:'+path.join(root,p)),path.join(__dirname,'DesktopBridge.cs')],'',30000);
    ready=true;
  }
  async function native(body,res){await prepare();const raw=await processCall(exe,[],JSON.stringify(body),12000,res);let data;try{data=JSON.parse(raw.replace(/^\uFEFF/,''));}catch{throw Error('Windows helper returned an unreadable response.');}if(!data.ok)throw Error(data.error||'Accessibility operation failed.');return data.data;}
  function stop(){run=null;catalog.clear();child?.kill();}
  function valid(current){return current && Date.now()<current.expiresAt;}
  function active(body,current){if(!run||run.id!==body.runId||run.session!==current||Date.now()>run.expires)throw Error('Agent run stopped or expired. Start a new task.');return run;}
  async function handle(endpoint,body,current,res,isCurrent){
    if(endpoint==='/desktop/stop'){if(run?.session===current)stop();return{message:'Agent stopped. No further steps will run. A completed app action cannot be undone automatically.'};}
    if(!valid(current)||!current.scopes.includes('ui-read'))throw Error('Pair with Windows app access first.');
    if(busy)throw Error('Another desktop operation is still finishing. Try again in a moment.');
    busy=true;
    try{
      if(endpoint==='/desktop/windows'){
        if(run)throw Error('Stop the current task before changing apps.');
        const data=await native({op:'windows'},res);if(!isCurrent())throw Error('Session was revoked.');catalog.clear();
        return{windows:data.windows.map(w=>{const id=crypto.randomUUID();catalog.set(id,{...w,expires:Date.now()+120000});return{id,title:w.title,app:w.app};})};
      }
      if(endpoint==='/desktop/start'){
        if(run)throw Error('An app task is already active. Stop it first.');
        if(!current.scopes.includes('ui-control'))throw Error('App control permission is missing.');
        if(typeof body.task!=='string'||!body.task.trim()||body.task.length>4000||body.cloudConsent!==true)throw Error('Enter a task and allow sharing the selected app text with Sarvam.');
        const target=catalog.get(body.target);if(!target||Date.now()>target.expires)throw Error('Refresh and select an app again.');
        if(current.mode!=='trusted' && !await confirm('Operate '+target.app+' for this task?\n'+body.task+'\nThe selected app text will be shared with Sarvam. Up to 12 steps; 5 minute limit.',res))throw Error('App task not approved.');
        if(!isCurrent()||res.destroyed)throw Error('Session was revoked or request cancelled.');
        run={id:crypto.randomUUID(),session:current,target,task:body.task,expires:Date.now()+300000,steps:0,snapshot:null};
        return{runId:run.id,message:'Selected app task started.'};
      }
      const r=active(body,current);
      if(endpoint==='/desktop/observe'){
        const data=await native({op:'observe',...r.target},res);
        if(run!==r||!isCurrent())throw Error('Task stopped.');
        const token=crypto.randomUUID();r.snapshot={token,at:Date.now(),nodes:new Map(data.controls.map(c=>[c.id,c]))};
        return{...data,snapshot:token};
      }
      if(endpoint!=='/desktop/act')throw Error('Unsupported desktop endpoint.');
      if(r.steps>=12)throw Error('The 12-step limit was reached. Review the app and start another task if needed.');
      const snap=r.snapshot,node=snap?.nodes.get(body.id);
      if(!node||snap.token!==body.snapshot||Date.now()-snap.at>60000)throw Error('App observation is stale. Read the app again.');
      if(!node.enabled||!node.actions.includes(body.action)||!['setValue','invoke','select','toggle','expand','scroll'].includes(body.action))throw Error('That control does not support this action.');
      if(body.action==='setValue'&&(typeof body.text!=='string'||body.text.length>4000))throw Error('Field text must be at most 4,000 characters.');
      if(body.action==='scroll'&&!['up','down'].includes(body.direction))throw Error('Unsupported scroll direction.');
      const description=node.name+' '+node.type;
      // Credential fields and command entry are excluded even in a trusted session.
      if(/password|passcode|one.?time|verification code|api.?key|secret|terminal|command.?line|address and search|address bar|omnibox/i.test(description))throw Error('This field requires your direct input. JARVIS will not enter credentials or commands here.');
      const sensitive=/send|submit|publish|post\b|delete|remove|pay|purchase|buy\b|transfer|install|uninstall|security|permission|allow|accept|confirm|save|sign|log.?in|close|exit|discard|enable|disable|execute|run\b/i.test(node.name);
      const navigation=['select','expand','scroll'].includes(body.action);
      const knownButton=/^(back|forward|next|previous|search|find|help|view|zoom in|zoom out|[0-9]|plus|minus|multiply|divide|equals|clear|add|subtract)$/i.test(node.name.trim());
      const needsApproval=current.mode!=='trusted'||sensitive||(!navigation&&body.action!=='setValue'&&!(body.action==='invoke'&&knownButton));
      r.snapshot=null;
      if(needsApproval){const ok=await confirm('App task: '+r.task+'\nIn '+r.target.app+': '+body.action+' on "'+node.name+'"'+(body.action==='setValue'?'\nReplace field text with:\n'+body.text:'')+'\nApprove this specific step?',res);if(!ok)throw Error('Step denied. Review the app before continuing.');}
      if(run!==r||!isCurrent()||res.destroyed||Date.now()>r.expires)throw Error('Task stopped or expired before the action.');
      r.steps++;
      const result=await native({op:'act',...r.target,id:node.id,name:node.name,type:node.type,action:body.action,text:body.text,direction:body.direction},res);
      if(run!==r||!isCurrent())throw Error('Stopped. The last action may have completed; inspect the app.');
      console.log('[Desktop] '+r.target.app+' · '+body.action+' · '+node.name);
      return result;
    }finally{busy=false;}
  }
  return{prepare,handle,stop};
};
