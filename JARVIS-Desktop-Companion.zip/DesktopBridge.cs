using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Principal;
using System.Windows.Automation;
using System.Web.Script.Serialization;

// Fixed UI Automation bridge. Reads one JSON request; emits one JSON result.
// It accepts accessibility operations only, never shell commands or scripts.
class DesktopBridge {
    static JavaScriptSerializer json = new JavaScriptSerializer { MaxJsonLength = 131072 };
    static string Str(Dictionary<string, object> d, string k) { return d.ContainsKey(k) ? Convert.ToString(d[k], CultureInfo.InvariantCulture) : ""; }
    static Dictionary<string, object> Obj(params object[] fields) {
        var d = new Dictionary<string, object>(); for (int i=0;i<fields.Length;i+=2) d[(string)fields[i]]=fields[i+1]; return d;
    }
    static string Clip(string s, int n) { return s == null ? "" : s.Substring(0, Math.Min(s.Length,n)); }
    static string Key(AutomationElement e) { return string.Join(".", e.GetRuntimeId()); }
    static bool Blocked(Process p) {
        string n=p.ProcessName.ToLowerInvariant();
        return new HashSet<string> { "cmd", "powershell", "pwsh", "windowsterminal", "conhost", "openconsole", "regedit", "mmc", "taskmgr", "consent", "credentialuibroker", "keepass", "1password", "bitwarden", "systemsettings" }.Contains(n);
    }
    static string Stamp(Process p) { return p.StartTime.ToUniversalTime().Ticks.ToString(CultureInfo.InvariantCulture); }
    static AutomationElement Window(Dictionary<string, object> d) {
        var e=AutomationElement.FromHandle(new IntPtr(long.Parse(Str(d,"handle"),CultureInfo.InvariantCulture)));
        var p=Process.GetProcessById(e.Current.ProcessId);
        if (Blocked(p) || p.Id.ToString()!=Str(d,"pid") || Stamp(p)!=Str(d,"stamp")) throw new Exception("The selected app closed, changed, or is excluded from automation. Refresh the window list.");
        if (e.Current.ControlType != ControlType.Window && p.MainWindowHandle.ToInt64().ToString()!=Str(d,"handle")) throw new Exception("Select a top-level app window.");
        return e;
    }
    static List<AutomationElement> Walk(AutomationElement root) {
        var result=new List<AutomationElement>(); var queue=new Queue<AutomationElement>(); queue.Enqueue(root);
        var watch=Stopwatch.StartNew();
        while(queue.Count>0 && result.Count<1200 && watch.ElapsedMilliseconds<4500) {
            var e=queue.Dequeue(); result.Add(e);
            try {
                if(e.Current.IsPassword) continue;
                var child=TreeWalker.ControlViewWalker.GetFirstChild(e); int count=0;
                while(child!=null && count++<200 && queue.Count<1200) { queue.Enqueue(child); child=TreeWalker.ControlViewWalker.GetNextSibling(child); }
            } catch (ElementNotAvailableException) {}
        }
        return result;
    }
    static Dictionary<string,object> Describe(AutomationElement e) {
        var c=e.Current; if(c.IsPassword || c.IsOffscreen) return null;
        if(Regex.IsMatch(c.Name ?? "", "password|passcode|one.?time|verification code|api.?key|secret", RegexOptions.IgnoreCase))return null;
        var patterns=new List<string>(); object p; string value="";
        if(e.TryGetCurrentPattern(ValuePattern.Pattern,out p)) { var v=(ValuePattern)p; value=Clip(v.Current.Value,700); if(!v.Current.IsReadOnly)patterns.Add("setValue"); }
        else if(e.TryGetCurrentPattern(TextPattern.Pattern,out p)) value=Clip(((TextPattern)p).DocumentRange.GetText(700),700);
        if(e.TryGetCurrentPattern(InvokePattern.Pattern,out p))patterns.Add("invoke");
        if(e.TryGetCurrentPattern(SelectionItemPattern.Pattern,out p))patterns.Add("select");
        if(e.TryGetCurrentPattern(TogglePattern.Pattern,out p))patterns.Add("toggle");
        if(e.TryGetCurrentPattern(ExpandCollapsePattern.Pattern,out p))patterns.Add("expand");
        if(e.TryGetCurrentPattern(ScrollPattern.Pattern,out p))patterns.Add("scroll");
        string name=Clip(c.Name,250);
        if(name.Length==0 && value.Length==0 && patterns.Count==0)return null;
        return Obj("id",Key(e),"name",name,"type",c.ControlType.ProgrammaticName.Replace("ControlType.",""),"value",value,"enabled",c.IsEnabled,"actions",patterns);
    }
    [STAThread] static void Main() {
        Console.InputEncoding=new UTF8Encoding(false); Console.OutputEncoding=new UTF8Encoding(false);
        try {
            if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new Exception("Restart the companion without administrator privileges.");
            var d=json.Deserialize<Dictionary<string,object>>(Console.In.ReadToEnd()); string op=Str(d,"op");
            object result;
            if(op=="windows") {
                var list=new List<object>(); var windows=AutomationElement.RootElement.FindAll(TreeScope.Children,Condition.TrueCondition);
                for(int i=0;i<windows.Count && list.Count<60;i++)try {
                    var e=windows[i]; var c=e.Current; var p=Process.GetProcessById(c.ProcessId);
                    if(c.NativeWindowHandle==0 || c.IsOffscreen || string.IsNullOrWhiteSpace(c.Name) || Blocked(p))continue;
                    list.Add(Obj("handle",c.NativeWindowHandle.ToString(),"pid",p.Id.ToString(),"stamp",Stamp(p),"title",Clip(c.Name,200),"app",p.ProcessName));
                }catch(Exception){}
                result=Obj("windows",list);
            } else {
                var root=Window(d); var elements=Walk(root);
                if(op=="observe") {
                    var list=new List<object>(); int chars=0;
                    foreach(var e in elements)try { var node=Describe(e); if(node==null)continue; chars+=json.Serialize(node).Length; if(list.Count>=140||chars>35000)break; list.Add(node); }catch(ElementNotAvailableException){}
                    result=Obj("title",Clip(root.Current.Name,200),"controls",list,"limited",true);
                } else if(op=="act") {
                    AutomationElement found=null;
                    foreach(var e in elements)try{if(Key(e)==Str(d,"id")){found=e;break;}}catch(ElementNotAvailableException){}
                    if(found==null)throw new Exception("Control changed or disappeared. Observe the app again.");
                    var c=found.Current;
                    if(c.IsPassword || !c.IsEnabled || c.IsOffscreen || Clip(c.Name,250)!=Str(d,"name") || c.ControlType.ProgrammaticName.Replace("ControlType.","")!=Str(d,"type"))throw new Exception("Control changed or is unavailable. Observe again.");
                    string action=Str(d,"action"); object pattern;
                    if(action=="setValue" && found.TryGetCurrentPattern(ValuePattern.Pattern,out pattern)) {
                        if(((ValuePattern)pattern).Current.IsReadOnly)throw new Exception("This field is read-only.");
                        string text=Str(d,"text"); if(text.Length>4000)throw new Exception("Text exceeds 4,000 characters."); ((ValuePattern)pattern).SetValue(text);
                    } else if(action=="invoke" && found.TryGetCurrentPattern(InvokePattern.Pattern,out pattern))((InvokePattern)pattern).Invoke();
                    else if(action=="select" && found.TryGetCurrentPattern(SelectionItemPattern.Pattern,out pattern))((SelectionItemPattern)pattern).Select();
                    else if(action=="toggle" && found.TryGetCurrentPattern(TogglePattern.Pattern,out pattern))((TogglePattern)pattern).Toggle();
                    else if(action=="expand" && found.TryGetCurrentPattern(ExpandCollapsePattern.Pattern,out pattern))((ExpandCollapsePattern)pattern).Expand();
                    else if(action=="scroll" && found.TryGetCurrentPattern(ScrollPattern.Pattern,out pattern))((ScrollPattern)pattern).Scroll(ScrollAmount.NoAmount,Str(d,"direction")=="up"?ScrollAmount.SmallDecrement:ScrollAmount.SmallIncrement);
                    else throw new Exception("The app does not expose that accessibility operation.");
                    result=Obj("message","Accessibility operation completed. Observe the app to confirm the result.");
                } else throw new Exception("Unsupported operation.");
            }
            Console.Write(json.Serialize(Obj("ok",true,"data",result)));
        }catch(Exception e){Console.Write(json.Serialize(Obj("ok",false,"error",Clip(e.Message,400))));Environment.ExitCode=1;}
    }
}
