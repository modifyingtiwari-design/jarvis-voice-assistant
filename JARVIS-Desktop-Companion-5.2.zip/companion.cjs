'use strict';
// JARVIS desktop companion. No dependencies, arbitrary commands or remote filesystem API.
const http=require('node:http'),crypto=require('node:crypto'),readline=require('node:readline');
const os=require('node:os'),path=require('node:path'),fs=require('node:fs');
const {spawn}=require('node:child_process');
const HOST='127.0.0.1',PORT=4317;
const ORIGINS=new Set(['https://jarvis-voice-assistant-bay.vercel.app','https://modifyingtiwari-design.github.io']);
const major=Number(process.versions.node.split('.')[0]);
if(major<22){console.error('Install Node.js 22 or newer from https://nodejs.org/ and run again.');process.exit(1);}
if(!process.stdin.isTTY){console.error('Run this companion in an interactive terminal. Approval input is required.');process.exit(1);}
if(!['win32','darwin','linux'].includes(process.platform)){console.error('This companion supports Windows, macOS and Linux desktops.');process.exit(1);}
const pairingCode=crypto.randomBytes(32).toString('hex'),pairExpires=Date.now()+10*60*1000;
let session=null,approval=null,attempts=[];
const terminal=readline.createInterface({input:process.stdin,output:process.stdout});
terminal.on('line',line=>{if(approval)approval(line.trim().toLowerCase()==='yes');});
function confirm(description,response){return new Promise(resolve=>{if(approval){resolve(false);return;}let settled=false;const finish=allowed=>{if(settled)return;settled=true;clearTimeout(timer);response.removeListener('close',closed);approval=null;console.log(allowed?'Approved.':'Denied or timed out.');resolve(allowed);};const closed=()=>{if(!response.writableEnded)finish(false);};const timer=setTimeout(()=>finish(false),45000);approval=finish;response.once('close',closed);console.log('\nPERMISSION REQUEST\n'+description+'\nType yes and press Enter to allow. Any other reply denies. (45 seconds)');});}
function equal(a,b){const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&crypto.timingSafeEqual(x,y);}
function send(res,code,data){if(res.destroyed||res.writableEnded)return;res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
function readBody(req){return new Promise((resolve,reject)=>{let size=0,parts=[];req.on('data',chunk=>{size+=chunk.length;if(size>4096){reject(Error('Request too large.'));req.destroy();}else parts.push(chunk);});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(parts).toString('utf8')||'{}'));}catch{reject(Error('Invalid JSON.'));}});req.on('error',reject);});}
function chromeSpec(target){
  let url='';
  if(target!==undefined){
    if(typeof target!=='string'||target.length>2000||/[\r\n\0]/.test(target))throw Error('Invalid Chrome website address.');
    let u;try{u=new URL(target);}catch{throw Error('Invalid Chrome website address.');}
    if(u.protocol!=='https:'||u.username||u.password)throw Error('Chrome can only open HTTPS websites without embedded credentials.');
    url=u.href;
  }
  let command,args=[];
  if(process.platform==='win32'){
    const roots=[process.env.ProgramFiles,process.env['ProgramFiles(x86)'],process.env.LOCALAPPDATA].filter(Boolean);
    command=roots.map(root=>path.join(root,'Google','Chrome','Application','chrome.exe')).find(file=>fs.existsSync(file));
    args=url?[url]:[];
  }else if(process.platform==='darwin'){
    const app=['/Applications/Google Chrome.app',path.join(os.homedir(),'Applications','Google Chrome.app')].find(file=>fs.existsSync(file));
    if(app){command='/usr/bin/open';args=['-a',app,...(url?[url]:[])];}
  }else{
    command=['/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/opt/google/chrome/chrome'].find(file=>fs.existsSync(file));
    args=url?[url]:[];
  }
  if(!command)throw Error('Google Chrome was not found in a standard installation location. Install Chrome, or use Open google / Open gmail.com to open a website in your current browser.');
  return{command,args,label:'Google Chrome'+(url?' → '+url:''),scope:'apps'};
}

function actionSpec(id,target){if(id==='chrome')return chromeSpec(target);if(!['calculator','editor','home','documents','downloads'].includes(id))return null;const folders={home:os.homedir(),documents:path.join(os.homedir(),'Documents'),downloads:path.join(os.homedir(),'Downloads')};const label={calculator:'Calculator',editor:'Text editor',home:'Home folder',documents:'Documents folder',downloads:'Downloads folder'}[id];if(!label)return null;const isFolder=Object.hasOwn(folders,id);if(isFolder&&!fs.existsSync(folders[id]))throw Error(label+' was not found. Redirected/custom folders are not supported by this version.');let command,args=[];if(process.platform==='win32'){const root=process.env.SystemRoot||'C:\\Windows';if(isFolder){command=path.join(root,'explorer.exe');args=[folders[id]];}else command=path.join(root,'System32',id==='calculator'?'calc.exe':'notepad.exe');}else if(process.platform==='darwin'){command='/usr/bin/open';args=isFolder?[folders[id]]:['-a',id==='calculator'?'Calculator':'TextEdit'];}else{command=isFolder?'/usr/bin/xdg-open':id==='calculator'?'/usr/bin/gnome-calculator':'/usr/bin/gedit';args=isFolder?[folders[id]]:[];}if(!fs.existsSync(command))throw Error(label+' launcher is not installed at the supported location.');return{command,args,label,scope:isFolder?'folders':'apps'};}
function launch(spec){return new Promise((resolve,reject)=>{const child=spawn(spec.command,spec.args,{shell:false,stdio:'ignore',detached:true});child.once('error',()=>reject(Error('The operating system could not launch '+spec.label+'.')));child.once('spawn',()=>{child.unref();resolve();});});}
const server=http.createServer(async(req,res)=>{
  const origin=req.headers.origin;
  if(req.headers.host!==HOST+':'+PORT||!ORIGINS.has(origin)){send(res,403,{error:'This origin or host is not allowed.'});return;}
  res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');
  if(req.method==='OPTIONS'){res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Private-Network','true');res.writeHead(204);res.end();return;}
  if(req.method!=='POST'||!['/pair','/action','/disconnect'].includes(req.url)){send(res,404,{error:'Unsupported endpoint.'});return;}
  if(!String(req.headers['content-type']||'').startsWith('application/json')){send(res,415,{error:'JSON is required.'});return;}
  attempts=attempts.filter(t=>Date.now()-t<60000);if(attempts.length>=20){send(res,429,{error:'Too many requests. Wait one minute.'});return;}attempts.push(Date.now());
  const token=String(req.headers.authorization||'').replace(/^Bearer /,'');
  try{
    if(req.url==='/pair'){
      if(Date.now()>pairExpires||!equal(token,pairingCode)){send(res,401,{error:'Pairing code is invalid or expired. Restart the companion for a fresh code.'});return;}
      if(approval){send(res,409,{error:'Finish the current terminal permission request first.'});return;}
      const body=await readBody(req);const scopes=body.scopes;
      if(!Array.isArray(scopes)||!scopes.length||scopes.length>2||scopes.some(s=>!['apps','folders'].includes(s))){send(res,400,{error:'Select apps and/or folders permission.'});return;}
      const granted=await confirm('Pair '+origin+'?\nPermissions: '+scopes.join(', ')+'. Session lasts 30 minutes. Each action still asks here.',res);
      if(!granted||res.destroyed){send(res,403,{error:'Pairing was not approved on the computer.'});return;}
      session={token:crypto.randomBytes(32).toString('hex'),origin,scopes:[...new Set(scopes)],expiresAt:Date.now()+30*60*1000};
      send(res,200,{...session,platform:process.platform,version:'5.2',capabilities:['calculator','editor','home','documents','downloads','chrome']});return;
    }
    const current=session;
    if(!current||Date.now()>current.expiresAt||current.origin!==origin||!equal(token,current.token)){send(res,401,{error:'Pair this computer again. The session is missing, expired or revoked.'});return;}
    if(req.url==='/disconnect'){session=null;if(approval)approval(false);send(res,200,{message:'Disconnected.'});return;}
    if(approval){send(res,409,{error:'Finish the current terminal permission request first.'});return;}
    const body=await readBody(req);const spec=actionSpec(body.action,body.url);
    if(!spec){send(res,400,{error:'That action is not supported.'});return;}
    if(!current.scopes.includes(spec.scope)){send(res,403,{error:'This action was not included in your pairing permissions.'});return;}
    const granted=await confirm('From '+origin+'\nOpen '+spec.label+' on this computer?',res);
    if(!granted||res.destroyed||session!==current||Date.now()>current.expiresAt){send(res,403,{error:'Action denied, cancelled or session expired.'});return;}
    await launch(spec);send(res,200,{message:'Launch requested for '+spec.label+' on this computer.'});
  }catch(e){send(res,400,{error:e.message});}
});
server.requestTimeout=80000;server.headersTimeout=10000;server.keepAliveTimeout=5000;server.maxConnections=12;
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port 4317 is already in use. Close the other companion before starting another.':'Companion could not start: '+e.code);terminal.close();process.exit(1);});
server.listen(PORT,HOST,()=>{console.log('\nJARVIS DESKTOP COMPANION · VERSION 5.2\nOnly this computer can connect: http://'+HOST+':'+PORT+'\nNo commands run without your approval. Close this terminal or press Ctrl+C to revoke access.\n\nPAIRING CODE (expires in 10 minutes):\n'+pairingCode+'\n\nIn JARVIS, open Device tools and paste this code. Do not send it in chat.');});
function shutdown(){session=null;if(approval)approval(false);server.close();terminal.close();process.exit(0);}
terminal.on('close',()=>process.exit(0));process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
